import './App.css';
import Product from './components/Product';

function App() {
  return (
    <div className="App">
      <h2>Cloth Store</h2>
      <Product />
    </div>
  );
}

export default App;
